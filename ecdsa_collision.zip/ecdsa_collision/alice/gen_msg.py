
msg1 = bytes.fromhex(
    "d131dd02c5e6eec4693d9a0698aff95c2fcab58712467eab4004583eb8fb7f89"
    "55ad340609f4b30283e488832571415a085125e8f7cdc99fd91dbdf280373c5b"
    "d8823e3156348f5bae6dacd436c919c61bf6ecf92855c5e91d54df5e7aacae4c"
    "7f5f36abac8c57f5ab1422c20e34c350b6f2a5a80f6f466cfbee94c2e25f9241"
    "2b7f5a0193f1f7a4a29be72e3f65fe803f6fda5046f9f2e6c235d7d6c6de9a7d"
    "5d8aa3b7f0e98c075c50b5e3c2f2c3d2a5c076f4c47f0ecf486be32cdbf2cc23"
    "015bb0d0f2dc9bbffb2f353b1f1d48c64517"
)

msg2 = bytes.fromhex(
    "d131dd02c5e6eec4693d9a0698aff95c2fcab58712467eab4004583eb8fb7f89"
    "55ad340609f4b30283e488832571415a085125e8f7cdc99fd91dbdf280373c5b"
    "d8823e3156348f5bae6dacd436c919c61bf6ecf92855c5e91d54df5e7aacae4c"
    "7f5f36abac8c57f5ab1422c20e34c350b6f2a5a80f6f466cfbee94c2e25f9241"
    "2b7f5a0193f1f7a4a29be72e3f65fe803f6fda5046f9f2e6c235d7d6c6de9a7d"
    "5d8aa3b7f0e98c075c50b5e3c2f2c3d2a5c076f4c47f0ecf486be32cdbf2cc23"
    "015bb0d0f2dc9bbffb2f353b1f1d48c64516"  
)

with open("msg1.bin", "wb") as f:
    f.write(msg1)
with open("msg2.bin", "wb") as f:
    f.write(msg2)

print("Created msg1.bin and msg2.bin with identical MD5 hashes.")
