from Crypto.PublicKey import ECC

key = ECC.generate(curve='P-256')
with open('key.pem', 'wt') as f:
    f.write(key.export_key(format='PEM'))

print("Created key.pem")
