from Crypto.Hash import MD5
from Crypto.Math.Numbers import Integer
from Crypto.PublicKey import ECC


def read_raw_signature(filename):
    with open(filename, 'rb') as f:
        sig = f.read()
    r = int.from_bytes(sig[:32], 'big')
    s = int.from_bytes(sig[32:], 'big')
    return r, s

r, s1 = read_raw_signature('sig1.bin')
_, s2 = read_raw_signature('sig2.bin')

with open('msg1.bin', 'rb') as f:
    z1 = int.from_bytes(MD5.new(f.read()).digest(), 'big')
with open('msg2.bin', 'rb') as f:
    z2 = int.from_bytes(MD5.new(f.read()).digest(), 'big')


r = Integer(r)
s1 = Integer(s1)
s2 = Integer(s2)
z1 = Integer(z1)
z2 = Integer(z2)

n = Integer(ECC.generate(curve='P-256')._curve.order)

k = ((z1 - z2) * (s1 - s2).inverse(n)) % n
d = ((s1 * k - z1) * r.inverse(n)) % n

with open('recovered_d.txt', 'w') as f:
    f.write(hex(int(d)))

print(f"Recovered d: {hex(int(d))}")
