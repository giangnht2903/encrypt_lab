from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from Crypto.Hash import MD5
from Crypto.Math.Numbers import Integer


d = int(input("Enter d: "),16)
curve = ECC._curves['P-256']
order = int(curve.order)
G = curve.G

pub_point = d * G 
key = ECC.construct(curve='P-256', d=d, point_x=int(pub_point.x), point_y=int(pub_point.y))
signer = DSS.new(key, 'deterministic-rfc6979') 

tmp = input("Enter fake message: ")
msg = tmp.encode('utf-8')
with open('msg_fake.bin', 'wb') as f:
    f.write(msg)

h = MD5.new(msg)
sig = signer.sign(h)

with open('sig_fake.bin', 'wb') as f:
    f.write(sig)

print("Fake message success.")
