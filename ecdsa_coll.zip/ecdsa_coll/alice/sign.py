from Crypto.PublicKey import ECC
from Crypto.Hash import MD5
from Crypto.Math.Numbers import Integer


with open('key.pem', 'rt') as f:
    key = ECC.import_key(f.read())
curve = key._curve
G = curve.G
n = int(curve.order)
d = int(key.d)


with open('msg1.bin', 'rb') as f:
    msg1 = f.read()
with open('msg2.bin', 'rb') as f:
    msg2 = f.read()

z1 = int.from_bytes(MD5.new(msg1).digest(), 'big')
z2 = int.from_bytes(MD5.new(msg2).digest(), 'big')


k = Integer.random_range(min_inclusive=1, max_exclusive=n)


R = k * G
r = int(R.x) % n

s1 = (Integer(k).inverse(n) * (z1 + r * d)) % n
s2 = (Integer(k).inverse(n) * (z2 + r * d)) % n


with open('sig1.bin', 'wb') as f:
    f.write(r.to_bytes(32, 'big') + s1.to_bytes(32, 'big'))
with open('sig2.bin', 'wb') as f:
    f.write(r.to_bytes(32, 'big') + s2.to_bytes(32, 'big'))

print(f"Sign ok")
