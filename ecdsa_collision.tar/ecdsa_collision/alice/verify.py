from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from Crypto.Hash import MD5

with open('key.pem', 'rt') as f:
    key = ECC.import_key(f.read())

verifier = DSS.new(key, 'deterministic-rfc6979')  

with open('msg_fake.bin', 'rb') as f:
    msg = f.read()
with open('sig_fake.bin', 'rb') as f:
    sig = f.read()

h = MD5.new(msg)
try:
    verifier.verify(h, sig)
    print("Valid Signature.")
except ValueError:
    print("Invalid Signature.")
